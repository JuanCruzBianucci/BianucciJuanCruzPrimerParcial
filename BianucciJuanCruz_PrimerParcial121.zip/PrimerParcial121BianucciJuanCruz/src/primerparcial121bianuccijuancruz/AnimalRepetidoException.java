package primerparcial121bianuccijuancruz;

public class AnimalRepetidoException  extends RuntimeException
{
    public final static String MESSAGE = "El animal ya se encuentra en la lista"; 
    
    public AnimalRepetidoException()
    {
        super (MESSAGE);
    }
    
    
}
