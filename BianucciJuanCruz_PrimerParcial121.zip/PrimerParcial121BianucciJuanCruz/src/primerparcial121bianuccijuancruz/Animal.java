package primerparcial121bianuccijuancruz;

import java.util.Objects;

public abstract class Animal 
{
    private String nombre;
    private int edad;
    private double peso;
    private Dieta dieta;

    public Animal(String nombre, int edad, double peso, Dieta dieta) 
    {
        this.nombre = nombre;
        this.edad = edad;
        this.peso = peso;
        this.dieta = dieta;
    }

    public String getNombre() {
        return nombre;
    }

    public double getPeso() {
        return peso;
    }

    public Dieta getDieta() {
        return dieta;
    }
    
    @Override
    public boolean equals (Object a)
    {
        if (this == a)
        {
            return true;    
        }
        if (a == null)
        {
            return false;
        }
        
        if (a instanceof Animal an)
        {
            return (an.nombre.equals(nombre) && an.edad == edad);
        }
        
        return false;
    }       
    
    @Override 
    public int hashCode()
    {
        return Objects.hash(nombre, edad);
    }
    


    
    
    
    
    
    
}
