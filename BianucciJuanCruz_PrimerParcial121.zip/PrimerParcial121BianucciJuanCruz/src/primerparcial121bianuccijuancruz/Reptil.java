package primerparcial121bianuccijuancruz;

public class Reptil extends Animal
{
    private String tipoEscama; 
    private String regTemperatura;

    public Reptil(String nombre, int edad, double peso, Dieta dieta, String tipoEscama, String regTemperatura) 
    {
        super(nombre, edad, peso, dieta);
        this.tipoEscama = tipoEscama;
        this.regTemperatura = regTemperatura;
    }

    @Override
    public String toString() {
        return "Reptil [tipoEscama=" + tipoEscama + ", regTemperatura=" + regTemperatura + ']';
    }
    
    
    
    
    
    
}
