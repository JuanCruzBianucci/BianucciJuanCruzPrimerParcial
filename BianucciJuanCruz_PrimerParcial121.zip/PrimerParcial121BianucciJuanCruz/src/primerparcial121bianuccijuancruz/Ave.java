package primerparcial121bianuccijuancruz;

public class Ave extends Animal implements Vacunable       
{
    private double envergaduraAlas;

    public Ave(String nombre, int edad, double peso, Dieta dieta, double envergaduraAlas) 
    {
        super(nombre, edad, peso, dieta);
        this.envergaduraAlas = envergaduraAlas;
    }

    @Override
    public String toString() 
    {
        return "Ave [envergaduraAlas=" + envergaduraAlas;
    }

    
    
    
    
}
