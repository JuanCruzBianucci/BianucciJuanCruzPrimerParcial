package primerparcial121bianuccijuancruz;

public enum Dieta 
{
    HERVIBORO,
    CARNIVORO,
    OMNIVORO    
}
