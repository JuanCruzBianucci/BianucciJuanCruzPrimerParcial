package primerparcial121bianuccijuancruz;

public interface Vacunable 
{
    default void vacunar(String nombre)
    {
        System.out.println(nombre + " fue vacunado");
    }
        
}
