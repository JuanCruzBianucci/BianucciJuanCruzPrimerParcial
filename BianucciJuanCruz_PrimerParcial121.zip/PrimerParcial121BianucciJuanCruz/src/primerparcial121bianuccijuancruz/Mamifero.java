package primerparcial121bianuccijuancruz;

public class Mamifero extends Animal implements Vacunable
{

    public Mamifero(String nombre, int edad, double peso, Dieta dieta) 
    {
        super(nombre, edad, peso, dieta);
    }

    @Override
    public String toString() 
    {
        return "Mamifero [peso= " + getPeso() + ", dieta=" + getDieta();
    }


    
    
}
