package primerparcial121bianuccijuancruz;

public class Test 
{

    public static void main(String[] args) 
    {
        Zoologico z1 = new Zoologico("Parque Natural");
        
        Animal a1 = new Mamifero("Flipper", 5, 20.9, Dieta.OMNIVORO);
        Animal a2 = new Ave("Tuki", 2, 1.2, Dieta.HERVIBORO, 30);
        Animal a3 = new Reptil("Boa", 10, 17, Dieta.CARNIVORO, "Verde", "Sangre Fria");
        Animal a4 = new Mamifero("Chocolate", 15, 111.5, Dieta.OMNIVORO);
        Animal a5 = new Ave("Lolo", 1, 1, Dieta.OMNIVORO, 10);
        Animal a6 = new Reptil("Rey", 4, 4, Dieta.CARNIVORO, "Multicolor", "Sangre Fria");
        
        //repetidos
        Animal a7 = new Reptil("Rey", 4, 4, Dieta.CARNIVORO, "Multicolor", "Sangre Fria");        
        Animal a8 = new Reptil("Flipper", 5, 4, Dieta.CARNIVORO, "Multicolor", "Sangre Fria");
       
        try
        {
            z1.agregarAnimal(a1);
            z1.agregarAnimal(a2);
            z1.agregarAnimal(a3);
            z1.agregarAnimal(a4);
            z1.agregarAnimal(a5);
            z1.agregarAnimal(a6);
            z1.agregarAnimal(a7);
            z1.agregarAnimal(a8);
        }   
        
        catch (AnimalRepetidoException ex)
        {
            System.out.println(ex.getMessage());
            
        }
        
        System.out.println("-------------------------------");
        
        z1.mostrarAnimales();
        
        System.out.println("-------------------------------");
        
        z1.vacunarAnimales();

    }
    
}
