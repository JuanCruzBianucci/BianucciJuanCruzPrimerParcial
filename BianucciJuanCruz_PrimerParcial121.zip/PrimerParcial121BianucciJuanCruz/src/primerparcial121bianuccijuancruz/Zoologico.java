package primerparcial121bianuccijuancruz;
import java.util.List;
import java.util.ArrayList;

public class Zoologico 
{
    private String nombre;
    private ArrayList<Animal> animales;

    public Zoologico(String nombre) 
    {
        this.nombre = nombre;
        animales = new ArrayList<>();
    }
    
    public void agregarAnimal(Animal animal)
    {
        if (animales.contains(animal))
        {
            throw new AnimalRepetidoException();
        }
        
        animales.add(animal);
    }
    
    public void mostrarAnimales ()
    {
        for (Animal a : animales)
        {
            System.out.println(a);
        }
    }
    
    public void vacunarAnimales()
    {
        for (Animal a : animales)
        {
            String nombre = a.getNombre();
            if (a instanceof Vacunable v)
            {
                v.vacunar(nombre);
            }
                           
            else 
            {
                System.out.println(nombre + " No es vacunable.");
            }
        }
        
    }

    
    
}
